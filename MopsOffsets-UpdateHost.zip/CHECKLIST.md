﻿# Памятка

URL для приложения (Update URL) после включения Pages:
- https://<user>.github.io/<repo>/update.json

Прямая ссылка на APK после публикации Release:
- https://github.com/<user>/<repo>/releases/download/<tag>/<file>.apk

Мини‑правило:
- новая версия => увеличь versionCode в docs/update.json
