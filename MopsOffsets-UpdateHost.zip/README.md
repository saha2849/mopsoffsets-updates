﻿# MopsOffsets Update Host (GitHub)

Этот репозиторий нужен только для **авто‑обновления** приложения `MopsOffsets`.

## Что здесь хранится
- `docs/update.json` — файл, который читает приложение.

## Быстрый старт (самое простое)
1) Создай репозиторий на GitHub (Public), например: `mopsoffsets-updates`.
2) Загрузи в него содержимое этого архива.
3) Включи GitHub Pages:
   - Repo → **Settings** → **Pages**
   - **Build and deployment** → Source: **Deploy from a branch**
   - Branch: **main** / folder: **/docs**
   - Save
4) Подожди 1–2 минуты, появится ссылка вида:
   - `https://<user>.github.io/<repo>/update.json`
5) В приложении:
   - **Настройки** → **Update URL (JSON)** → вставь эту ссылку.
   - Нажми **Проверить**.

## Как выпускать обновление
1) Собери новый APK приложения.
2) Залей APK в **Releases** этого репозитория:
   - Repo → **Releases** → **Draft a new release**
   - Tag, например: `v1.0.2`
   - Прикрепи APK как asset (например `MopsOffsets-1.0.2.apk`)
   - Publish
3) Скопируй прямую ссылку на APK (она будет вида):
   - `https://github.com/<user>/<repo>/releases/download/v1.0.2/MopsOffsets-1.0.2.apk`
4) Открой `docs/update.json` и обнови:
   - `versionCode` (обязательно увеличить)
   - `versionName`
   - `apkUrl`
   - `notes`
5) Commit изменения.

Готово: приложение увидит обновление и покажет баннер.

## Важно
- `versionCode` должен быть больше текущего, иначе обновление не появится.
- Если включено **Автоскачивание** в приложении — APK начнёт скачиваться сам.
